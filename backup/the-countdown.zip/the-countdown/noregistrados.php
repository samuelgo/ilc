<?php
	class The_Countdown_Widget extends WP_Widget {

		echo "kekeke";


	}

?>